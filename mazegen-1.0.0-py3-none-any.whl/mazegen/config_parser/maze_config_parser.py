"""Parser that reads a key=value configuration file into a MazeConfig."""

from pydantic import ValidationError
from .maze_config import MazeConfig
from .maze_config_parser_error import (
    MazeConfigParserError,
)
from .maze_config_parser_error import (
    MazeConfigParserFileError,
)
from .maze_config_parser_error import (
    MazeConfigParserValueError,
)


class MazeConfigParser:
    """Reads and validates a maze configuration file.

    Provides static/class methods to parse a ``key=value`` text file and
    produce a validated ``MazeConfig`` instance.
    """

    @staticmethod
    def read_config_file(filename: str) -> dict[str, str]:
        """Read a configuration file and return its contents as a dict.

        Parses each non-empty, non-comment line as a ``key=value`` pair.
        Keys are normalised to lowercase.

        Args:
            filename: Path to the configuration file.

        Returns:
            A dictionary mapping lowercase keys to their string values.

        Raises:
            MazeConfigParserValueError: If a line contains more than one
                ``=`` separator.
            MazeConfigParserFileError: If the file cannot be opened or read.
        """
        try:
            raw_config: dict[str, str] = {}
            with open(filename, "r") as file:
                for line in file:
                    line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" not in line:
                        continue
                    splitted_line: list[str] = line.split("=")
                    if len(splitted_line) != 2:
                        raise MazeConfigParserValueError(
                            "Line must have only a key and a value "
                            f"(format:key=value) received: {splitted_line}"
                        )
                    key: str = splitted_line[0].strip()
                    value: str = splitted_line[1].strip()
                    raw_config[key.lower()] = value
            return raw_config
        except OSError as err:
            raise MazeConfigParserFileError(f"{err.filename}: {err.strerror}")

    @classmethod
    def load_config(cls, filename: str) -> MazeConfig:
        """Load and validate a maze configuration from a file.

        Reads raw key/value pairs via ``read_config_file`` and passes
        them through Pydantic validation to produce a ``MazeConfig``.

        Args:
            filename: Path to the configuration file.

        Returns:
            A fully validated ``MazeConfig`` instance.

        Raises:
            MazeConfigParserError: On file I/O or parsing errors.
            pydantic.ValidationError: If the parsed values fail validation.
        """
        raw_config: dict[str, str] = cls.read_config_file(filename)
        return MazeConfig.model_validate(raw_config)


if __name__ == "__main__":
    try:
        maze_config: MazeConfig = MazeConfigParser.load_config("config.txt")
        print(maze_config)
    except MazeConfigParserError as err:
        print(err.__class__.__name__, err)
    except ValidationError as err:
        for error in err.errors():
            field_path = " -> ".join(map(str, error["loc"])).upper()
            field = field_path if field_path else "validate_config"

            msg: str = error.get("msg", "empty")
            print(f"MazeConfig error, Field {field} : {msg}")
